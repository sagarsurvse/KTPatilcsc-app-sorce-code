package com.bcs.osm.ktpatilofbcsobad;

/**
 * Created by ADMIN on 12/28/2018.
 */

class NavigationView {
    public class OnNavigationItemSelectedListener {
    }
}
